import pandas as pd
from pyrda.dbms.rds import RdClient


def Redetail_ColumntoRow(filepath):

    rdhous_df = pd.read_excel(filepath)

    nonRedetail_col = ['序号', '工资类别', '会计年度', '会计期间', '原部门', '高新部门', '姓名', '费用承担组织', '个税申报组织', '非研发工资成本']

    nonRedetail_df = rdhous_df[nonRedetail_col]
    nonRedetail_df.to_excel(r'nonRedetail.xlsx')
    print(nonRedetail_df)

    Redetail_col = ['原部门', '高新部门', '姓名', '费用承担组织', '个税申报组织', '研发项目', '研发项目工资成本']


    rdhous_df = rdhous_df.set_index(
        ['序号', '工资类别', '会计年度', '会计期间', '原部门', '高新部门', '姓名', '费用承担组织', '个税申报组织',
         '单项总额', '研发工资成本', '非研发工资成本'])

    rdhous_df = rdhous_df.stack()

    rdhous_df.index = rdhous_df.index.rename('研发项目', level=12)

    rdhous_df.name = '研发项目工资成本'

    rdhous_df = rdhous_df.reset_index()

    Redetail_df = rdhous_df[Redetail_col]
    Redetail_df.rename(columns={'研发项目工资成本': '研发工资成本'})
    nonRedetail_df.to_excel(r'Redetail.xlsx')
    print(Redetail_df)

    return Redetail_df, nonRedetail_df


# 查询是否存在数据库
def DropDuplicates(token, excel, table):
    app = RdClient(token=token)
    df = pd.read_excel(excel)
    sql = f"""select FNumber from '{table}'"""
    FNumbers = app.select(sql)
    res = df.loc[df['FNumbers'] not in FNumbers]
    return res


def read_excel(excel):
    df = pd.read_excel(excel)
    return df


if __name__ == '__main__':

    # filepath = r"C:\Users\zzy1\Desktop\研发工时表.xlsx"
    # Redetail_ColumntoRow(filepath)
    pass