from pyrda.dbms.rds import RdClient
import pandas as pd
import pymysql
import configparser
import basecode
from sqlalchemy import create_engine
import os
import datetime


# 1,读数据，读工资表，社保表，研发工时表，非研发工时表
def sql_query(app, table):
    sql = f"""select * from {table}"""
    data = app.select(sql)
    res = pd.DataFrame(data)
    return res


# 2，工时表列转行，将工资类别（工资，社保，公积金）作为列名
def detail_specification(detail, condition, FRdProjectCost):
    detail = detail.groupby(condition)[FRdProjectCost].sum().to_frame().reset_index()
    detail = detail.set_index(condition)[FRdProjectCost].unstack()
    detail.columns.name = None
    detail = detail.reset_index()
    return detail


# 工资关联研发工时
def salary_merge_rddtail(salary, detail, condition):
    salary = salary.loc[(salary['FAccount'] == '研发支出') & (salary['FCategoryType'].str.contains('计提'))]
    salary = salary.drop('FOldDept', axis=1)
    data = pd.merge(salary, detail, how='left', on=condition)
    data['FRdProject'] = data['FRdProject'].fillna('')

    data['工资'] = data['工资'].fillna(0)
    data['奖金'] = data['奖金'].fillna(0)
    data['rnk'] = data.loc[(data['工资']!=0) | (data['奖金']!=0)].groupby(['FNumber', 'FHightechDept'])['FRdProject'].rank().astype('int64')
    data['rnk'].fillna(0)
    data.loc[(data['rnk'] != 1) & (data['rnk'] != 0), ['FFixdCost', 'FScraprateCost', 'FSocialSecurityAmt', 'FAccumulationFundAmt',
                                  'FOtherAmt', 'FIncomeTaxAmt', 'FActualAmount']] = 0
    data = data.drop(labels='rnk', axis=1)
    return data


# 工资关联非研发工时
def salary_merge_nonrddtail(salary, nonrddetail, nonrddetailcondition):
    salary = salary.loc[(salary['FAccount'] == '生产成本') & (salary['FCategoryType'].str.contains('计提'))]
    salary.loc[salary['FAccount'] == '生产成本', ['FOldDept']] = '生产部'
    salary = salary.drop('FHightechDept', axis=1)
    data = pd.merge(salary, nonrddetail, how='left', on=nonrddetailcondition)
    return data


# 社保关联研发工时
def socialsecurity_merge_rddtail(socialsecurity, detail, condition):
    socialsecurity = socialsecurity.loc[
        (socialsecurity['FAccount'] == '研发支出') & (socialsecurity['FCategoryType'].str.contains('计提'))]
    socialsecurity = socialsecurity.drop('FOldDept', axis=1)
    data = pd.merge(socialsecurity, detail, how='left', on=condition)
    data['FRdProject'] = data['FRdProject'].fillna('')
    data['社保'] = data['社保'].fillna(0)
    data['公积金'] = data['公积金'].fillna(0)
    data['rnk1'] = data.loc[data['社保'] != 0].groupby(['FNumber', 'FHightechDept'])['FRdProject'].rank().astype('int64')
    data['rnk2'] = data.loc[data['公积金'] != 0].groupby(['FNumber', 'FHightechDept'])['FRdProject'].rank().astype('int64')
    data['rnk1'] = data['rnk1'].fillna(0)
    data['rnk2'] = data['rnk2'].fillna(0)
    data['rnk1'] = data['rnk1'].astype('int64')
    data['rnk2'] = data['rnk2'].astype('int64')
    data.loc[(data['rnk1'] != 1) & (data['rnk1'] != 0) | (data['rnk2'] != 1) & (data['rnk2'] != 0),
    ['FComPensionBenefitsAmt', 'FComMedicareAmt', 'FComMedicareOfSeriousAmt',
                                  'FComDisabilityBenefitsAmt',
                                  'FComOffsiteElseAmt', 'FComWorklessInsuranceAmt', 'FComInjuryInsuranceAmt',
                                  'FComMaternityInsuranceAmt',
                                  'FComAllSoSeAcFuAmt', 'FEmpPensionBenefitsAmt', 'FEmpMedicareAmt',
                                  'FEmpMedicareOfSeriousAmt', 'FEmpWorklessInsuranceAmt',
                                  'FEmpAllSocialSecurityAmt', 'FEmpAccumulationFundAmt', 'FEmpAllSoSeAcFuAmt',
                                  'FAllSocialSecurityAmt',
                                  'FAllAccumulationFundAmt', 'FAllAmount', 'FManagementAmount']] = 0
    data = data.drop(labels='rnk1', axis=1)
    data = data.drop(labels='rnk2', axis=1)
    return data


# 社保关联非研发工时
def socialsecurity_merge_nonrddtail(socialsecurity, nonrddetail, condition):
    socialsecurity = socialsecurity.loc[
        (socialsecurity['FAccount'] == '生产成本') & (socialsecurity['FCategoryType'].str.contains('计提'))]
    socialsecurity.loc[socialsecurity['FAccount'] == '生产成本', ['FOldDept']] = '生产部'
    socialsecurity = socialsecurity.drop('FHightechDept', axis=1)
    data = pd.merge(socialsecurity, nonrddetail, how='left', on=condition)
    return data


def main(FToken):
    app = RdClient(token=FToken)
    # 查工资
    salary = sql_query(app, 'rds_hrv_ods_ds_salary')
    salary = salary.drop('FRdProject', axis=1)

    # 查社保公积金
    socialsecurity = sql_query(app, 'rds_hrv_ods_ds_socialsecurity')
    socialsecurity = socialsecurity.drop('FRdProject', axis=1)

    detailcondition = ['FNumber', 'FYear', 'FMonth', 'FHightechDept', 'FExpenseOrgID', 'FTaxDeclarationOrg',
                       'FRdProject', 'FOldDept', 'FSalaryType']
    rddetailcondition = ['FNumber', 'FYear', 'FMonth', 'FHightechDept', 'FExpenseOrgID', 'FTaxDeclarationOrg']
    nonrddetailcondition = ['FNumber', 'FYear', 'FMonth', 'FOldDept', 'FExpenseOrgID', 'FTaxDeclarationOrg']

    # 查研发工时
    rddetail = sql_query(app, 'rds_hrv_ods_ds_rddetail')
    rddetail = detail_specification(rddetail, detailcondition, 'FRdProjectCost')
    rddetail.to_excel('rddetailres.xlsx', index=False)

    # 查非研发工时
    nonrddetail = sql_query(app, 'rds_hrv_ods_ds_nonrddetail')
    nonrddetail['FRdProject'] = nonrddetail['FRdProject'].replace('', 'rds')
    nonrddetail = nonrddetail.loc[nonrddetail['FNonRdCost'] != 0]
    nonrddetail = detail_specification(nonrddetail, detailcondition, 'FNonRdCost')
    nonrddetail.to_excel('nonrddetailres.xlsx', index=False)

    # 工资
    salary_rddetail = salary_merge_rddtail(salary, rddetail, rddetailcondition)
    salary_rddetail['工资'] = salary_rddetail['工资'].fillna(0)
    salary_rddetail['奖金'] = salary_rddetail['奖金'].fillna(0)
    salary_rddetail['FCpayAmount'] = salary_rddetail['工资'] + salary_rddetail['奖金']
    salary_rddetail = salary_rddetail.loc[(salary_rddetail['工资'] != 0) | (salary_rddetail['奖金'] != 0)]

    salary = salary.loc[(salary['FAccount'] != '研发支出') | (
                (salary['FAccount'] == '研发支出') & salary['FCategoryType'].str.contains('发放'))]

    salary_nonrddetail = salary_merge_nonrddtail(salary, nonrddetail, nonrddetailcondition)
    salary_nonrddetail['工资'] = salary_nonrddetail['工资'].fillna(0)
    salary_nonrddetail['奖金'] = salary_nonrddetail['奖金'].fillna(0)
    salary_nonrddetail['FCpayAmount'] = salary_nonrddetail['FCpayAmount'] + salary_nonrddetail['工资'] + \
                                        salary_nonrddetail['奖金']

    salary = salary.loc[(salary['FAccount'] != '生产成本') | (
                (salary['FAccount'] == '生产成本') & salary['FCategoryType'].str.contains('发放'))]

    salaryrrddetail = pd.concat([salary_rddetail, salary_nonrddetail])
    # salaryrrddetail = salaryrrddetail.loc[(salaryrrddetail['工资'] != 0) | (salaryrrddetail['奖金'] != 0)]

    # salaryrrddetail['FCpayAmount'] = salaryrrddetail['工资'] + salaryrrddetail['奖金']
    salaryrrddetail = salaryrrddetail.drop(labels=['工资', '社保', '公积金', '奖金'], axis=1)

    salaryres = pd.concat([salary, salaryrrddetail])
    salaryres['FRdProject'] = salaryres['FRdProject'].replace('rds', '')
    salaryres['FRdProject'] = salaryres['FRdProject'].fillna('')
    salaryres['FHightechDept'] = salaryres['FHightechDept'].fillna('')
    salaryresods = sql_query(app, 'rds_hrv_ods_ds_salary')
    salaryresdiff = pd.concat([salaryres, salaryresods, salaryresods]).drop_duplicates(keep=False)
    salaryresdiff.to_excel('salaryres.xlsx', index=False)

    # 社保
    socialsecurity_rddetail = socialsecurity_merge_rddtail(socialsecurity, rddetail, rddetailcondition)

    socialsecurity_rddetail['社保'] = socialsecurity_rddetail['社保'].fillna(0)
    socialsecurity_rddetail['公积金'] = socialsecurity_rddetail['公积金'].fillna(0)
    socialsecurity_rddetail['FComAllSocialSecurityAmt'] = socialsecurity_rddetail['社保']
    socialsecurity_rddetail['FComAccumulationFundAmt'] = socialsecurity_rddetail['公积金']
    socialsecurity_rddetail = socialsecurity_rddetail.loc[
        (socialsecurity_rddetail['社保'] != 0) | (socialsecurity_rddetail['公积金'] != 0)]
    socialsecurity = socialsecurity.loc[(socialsecurity['FAccount'] != '研发支出')
                                        | ((socialsecurity['FAccount'] == '研发支出') & socialsecurity[
        'FCategoryType'].str.contains('发放'))]

    socialsecurity_nonrddetail = socialsecurity_merge_nonrddtail(socialsecurity, nonrddetail, nonrddetailcondition)
    socialsecurity_nonrddetail['社保'] = socialsecurity_nonrddetail['社保'].fillna(0)
    socialsecurity_nonrddetail['公积金'] = socialsecurity_nonrddetail['公积金'].fillna(0)
    socialsecurity_nonrddetail['FComAllSocialSecurityAmt'] = socialsecurity_nonrddetail['FComAllSocialSecurityAmt'] + \
                                                             socialsecurity_nonrddetail['社保']
    socialsecurity_nonrddetail['FComAccumulationFundAmt'] = socialsecurity_nonrddetail['FComAccumulationFundAmt'] + \
                                                            socialsecurity_nonrddetail['公积金']
    socialsecurity = socialsecurity.loc[(socialsecurity['FAccount'] != '生产成本')
                                        | ((socialsecurity['FAccount'] == '生产成本') & socialsecurity[
        'FCategoryType'].str.contains('发放'))]

    socialsecurityrddetail = pd.concat([socialsecurity_rddetail, socialsecurity_nonrddetail])
    # socialsecurityrddetail['社保'] = socialsecurityrddetail['社保'].fillna(0)
    # socialsecurityrddetail['公积金'] = socialsecurityrddetail['公积金'].fillna(0)

    # socialsecurityrddetail['FComAllSocialSecurityAmt'] = socialsecurityrddetail['社保']
    # socialsecurityrddetail['FComAccumulationFundAmt'] = socialsecurityrddetail['公积金']

    # socialsecurityrddetail = socialsecurityrddetail.loc[(socialsecurityrddetail['社保'] != 0) | (socialsecurityrddetail['公积金'] != 0)]
    socialsecurityrddetail = socialsecurityrddetail.drop(labels=['工资', '社保', '公积金', '奖金'], axis=1)

    socialsecurityres = pd.concat([socialsecurity, socialsecurityrddetail])
    socialsecurityres['FRdProject'] = socialsecurityres['FRdProject'].replace('rds', '')
    socialsecurityres['FRdProject'] = socialsecurityres['FRdProject'].fillna('')
    socialsecurityres['FHightechDept'] = socialsecurityres['FHightechDept'].fillna('')
    socialsecurityods = sql_query(app, 'rds_hrv_ods_ds_socialsecurity')
    socialsecuritydiff = pd.concat([socialsecurityres, socialsecurityods, socialsecurityods]).drop_duplicates(
        keep=False)
    socialsecuritydiff.to_excel('socialsecurityres.xlsx', index=False)

    # engine = con()
    # pd_to_sql(engine, salaryres, 'rds_hrv_ods_ds_salary')
    # pd_to_sql(engine, socialsecurityres, 'rds_hrv_ods_ds_socialsecurity')

    to_sql(app, 'salaryres.xlsx', 'rds_hrv_ods_ds_salary')
    to_sql(app, 'socialsecurityres.xlsx', 'rds_hrv_ods_ds_socialsecurity')
    return salaryres, socialsecurityres


# def con():
#     config = configparser.ConfigParser()
#     inidir = os.path.dirname(basecode.__file__)
#     inifiles = os.path.join(inidir, 'cfg.ini')
#     config.read(inifiles)
#     lingdangcrm = config["lingdangcrm"]
#     db_server = lingdangcrm['db_server']
#     db_port = lingdangcrm['db_port']
#     db_username = lingdangcrm['db_username']
#     db_password = lingdangcrm['db_password']
#     db_name = lingdangcrm['db_name']
#     pd_connect = f"""mssql+pymssql://{db_username}:{db_password}@{db_server}:{int(db_port)}/{db_name}?charset=utf8"""
#     engine = create_engine(pd_connect)
#     return engine
#
#
# def pd_to_sql(engine, data, table):
#     data.to_sql(table, con=engine, if_exists='append', index=False)


def to_sql(app, excel, table):
    data = pd.read_excel(excel)
    if not data.empty:
        data = data.fillna('')
        keys = tuple(data.columns)
        keys = "(" + ','.join(keys) + ")"
        values = ''
        for row in data.itertuples():
            value = list(row)[1:]
            value[-3] = value[-3].to_pydatetime().strftime('%Y-%m-%d')
            value = tuple(value)
            value = str(value)
            values = values + value + ','
        values = values[:-1]
        sql = f"""insert into {table} {keys} values {values}"""
        print(sql)
        app.insert(sql)


if __name__ == '__main__':
    # FToken = '1ED05534-A0EE-4BAF-89B2-8F1F5A0ABE70'
    FToken = '057A7F0E-F187-4975-8873-AF71666429AB'
    # app = RdClient(token=FToken)
    main(FToken)

    # salaryresods = sql_query(app, 'rds_hrv_ods_ds_salary')

    # socialsecurityods = sql_query(app, 'rds_hrv_ods_ds_socialsecurity')

    # to_sql(app, 'salaryres.xlsx', 'rds_hrv_ods_ds_salary')
    # to_sql(app, 'socialsecurityres.xlsx', 'rds_hrv_ods_ds_socialsecurity')

    # to_sql(app, r'salaryres.xlsx', 'rds_hrv_ods_ds_salary')
